## Example 5.6

## Import the Prime data file into a data frame (table) and label it myData.  

lower<-mean(myData$Expenditures)-qt(0.975, 99, lower.tail=TRUE)*sd(myData$Expenditures)/sqrt(100)
upper<-mean(myData$Expenditures)+qt(0.975, 99, lower.tail=TRUE)*sd(myData$Expenditures)/sqrt(100)
lower
upper

##For one-step approach use the following

t.test(myData$Expenditures)

## Example 5.12

## Import the Study_Hours data file into a data frame (table) and label it myData.  

t.test(myData$Hours, alternative="two.sided", mu=14)




