## The following library needs to be installed only once for this chapter

install.packages("sandwich")

## Example 6.1

## Import the College data file into a data frame (table) and label it myData.  

options(scipen=999)
Multiple<-lm(Earnings~Cost+Grad+Debt+City, data=myData)
summary(Multiple)

## Replicating Figure 6.10 and Obtaining Robust Standard Errors

## Import the Convenience_Stores data file into a data frame (table) and label it myData.  

library(sandwich)
Simple<-lm(Sales~Sqft, data=myData)
Simple_Residuals<-resid(Simple)
plot(Simple_Residuals~myData$Sqft, xlab="Sqft", ylab="e")
vcovHC(Simple, type="HC1")
Simple_SE<-diag(vcovHC(Simple,type="HC1"))^0.5
Simple_SE

## Replicating Figure 6.11 and Obtaining Robust Standard Errors

## Import the Sushi_Restaurant data file into a data frame (table) and label it myData.  

library(sandwich)
Multiple<-lm(Sales~AdsCost+Unemp, data=myData)
Multiple_Residuals<-resid(Multiple)
T<-seq(from=1, to=length(Multiple_Residuals))
plot(Multiple_Residuals~T, xlab="time", ylab="e")
abline(h=0)
NeweyWest(Multiple, prewhite=FALSE)
Multiple_SE<-diag(NeweyWest(Multiple))^0.5
Multiple_SE



