## Example 7.8

## Import the AnnArbor data file into a data frame (table) and label it myData.  

Model4 <- lm(log(Rent) ~ Beds+Baths+log(Sqft), data=myData)
summary(Model4)
Pred_lnRent<-predict(Model4)
SE<-summary(Model4)$sigma
Pred_Rent<-exp(Pred_lnRent+SE^2/2)
cor(myData$Rent, Pred_Rent)^2

## Example 7.10 and 7.11
## Import the Mortgage data file into a data frame (table) and label it myData. 

Logistic_Model <- glm(y ~ x1 + x2, family = binomial(link = logit), data = myData)
Pred <- predict(Logistic_Model, type = "response")
Binary <- round(Pred)
100*mean(myData$y == Binary)


## Example 7.14
## Import the Spam data file into a data frame (table) and label it myData. 

TData <- myData[1:375,]
VData <- myData[376:500,]
Model1 <- glm(Spam ~ Recipients + Hyperlinks + Characters, family = binomial(link = logit), data = TData)
Pred1 <- predict(Model1, VData, type = "response")
Binary1 <- round(Pred1)
100*mean(VData$Spam == Binary1)
Model2 <- glm(Spam ~ Recipients + Hyperlinks, family = binomial(link = logit), data = TData)
Pred2 <- predict(Model2, VData, type = "response")
Binary2 <- round(Pred2)
100*mean(VData$Spam == Binary2)

Model11 <- glm(Spam ~ Recipients + Hyperlinks + Characters, family = binomial(link = logit), data = myData)
summary(Model11)
